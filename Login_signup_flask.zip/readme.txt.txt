

python db.py
crud example
-------------------------------
setup video
http://127.0.0.1:5000/
flask run
pip install flask